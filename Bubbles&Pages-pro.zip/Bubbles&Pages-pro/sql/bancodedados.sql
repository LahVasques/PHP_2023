CREATE DATABASE loja;
USE loja;

create table usuarios (id int 
auto_increment primary key,
nome varchar(255),
email varchar(255),
senha varchar(255));
select * from produtos


CREATE TABLE produtos (
    id INT NOT NULL AUTO_INCREMENT, 
    tipo VARCHAR(45) NOT NULL, 
    nome VARCHAR(45) NOT NULL, 
    imagem VARCHAR(80) NOT NULL, 
    preco DECIMAL(5,2) NOT NULL, 
    data_ DATE NOT NULL,
    avaliacao INT NOT NULL, 
	curtido INT NOT NULL, 
    PRIMARY KEY (id)
);

drop table produtos

INSERT INTO `produtos` (tipo, nome, imagem, preco, data_, avaliacao, curtido) VALUES
('Marvel', 'Amazing Spider-Man #23 Disney What If Infinit', 'img/feature-6.jpg', 30.00, '2023-01-01', 5, 1),
('DC Comics', 'A Saga do Batman Vol. 63', 'img/feature-1.jpg', 39.90, '2023-02-15', 4, 0),
('DC Comics', 'Hera Venenosa Vol. 01', 'img/feature-3.jpg', 32.50, '2023-03-22', 3, 1),
('DC Comics', 'Liga da Justiça Vol. 61', 'img/feature-4.jpg', 22.90, '2023-04-10', 4, 1),
('DC Comics', 'Liga da Justiça Vol. 61', 'img/feature-4.jpg', 22.90, '2023-04-10', 4, 0),
('DC Comics', 'Liga da Justiça Vol. 61', 'img/feature-4.jpg', 22.90, '2023-04-10', 4, 0);
 
SELECT * FROM produtos ORDER BY avaliação DESC LIMIT 6

