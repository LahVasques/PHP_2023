CREATE DATABASE loja
USE loja

CREATE TABLE `usuarios` (
  `idusuario` int(11) NOT NULL,
  `nome` varchar(80) NOT NULL,
  `email` varchar(80) NOT NULL,
  `senha` varchar(64) NOT NULL
)

INSERT INTO `usuarios` (`idusuario`, `nome`, `email`, `senha`) VALUES
(8, 'Amanda Araújo', 'amanda@gmail.com', 'teste'),
(14, 'sabrina', 'sabrina@gmail.com', 'teste2'),
(15, 'Bruna Luiza', 'bruna@gmail.com', 'lindex'),
(16, 'laiss', 'laiss@gmail.com', 'teste');

