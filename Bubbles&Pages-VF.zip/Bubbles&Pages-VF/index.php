<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <meta charset="UTF-8" />
    <meta name="description" content="Ogani Template" />
    <meta name="keywords" content="Ogani, unica, creative, html" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>Bubbles & Pages</title>

    <!-- Google Font -->
    <link rel="icon" href="img/icon.png" type="image/png">
    <link rel="icon" href="icon.png" sizes="16x16" type="image/png">
    <link rel="icon" href="icon.png" sizes="32x32" type="image/png">
    <link
      href="https://fonts.googleapis.com/css2?family=Cairo:wght@200;300;400;600;900&display=swap"
      rel="stylesheet"
    />

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" />
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css" />
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css" />
    <link rel="stylesheet" href="css/nice-select.css" type="text/css" />
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css" />
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css" />
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css" />
    <link rel="stylesheet" href="css/style.css" type="text/css" />
  </head>

  <body>
    <!-- Page Preloder -->
    <div id="preloder">
      <div class="loader"></div>
    </div>

    <!-- Humberger Begin -->
    <div class="humberger__menu__overlay"></div>
    <div class="humberger__menu__wrapper">
      <div class="humberger__menu__logo">
        <a href="#"><img src="img/logo.png" alt="" /></a>
      </div>
      <div class="humberger__menu__cart">
        <ul>
          <li>
            <a href="#"><i class="fa fa-heart"></i> <span>1</span></a>
          </li>
          <li>
            <a href="#"><i class="fa fa-shopping-bag"></i> <span>3</span></a>
          </li>
        </ul>
        <div class="header__cart__price">itens: <span>R$150.00</span></div>
      </div>
      <div class="humberger__menu__widget">
        <div class="header__top__right__auth">
          <a href="login.php"><i class="fa fa-user"></i> Login</a>
        </div>
      </div>
      <nav class="humberger__menu__nav mobile-menu">
        <ul>
          <li class="active"><a href="./index.php">Home</a></li>
          <li><a href="./shop-grid.html">Loja</a></li>
          <li>
            <a href="#">Páginas</a>
            <ul class="header__menu__dropdown">
              <li><a href="./shop-details.html">Detalhes da Compra</a></li>
              <li><a href="./shoping-cart.html">Carrinho</a></li>
              <li><a href="./checkout.html">Check Out</a></li>
              <li><a href="./blog-details.html">Blog Detalhes</a></li>
            </ul>
          </li>
          <li><a href="./blog.html">Blog</a></li>
          <li><a href="./contact.html">Contato</a></li>
        </ul>
      </nav>
      <div id="mobile-menu-wrap"></div>
      <div class="header__top__right__social">
        <a href="#"><i class="fa fa-facebook"></i></a>
        <a href="#"><i class="fa fa-twitter"></i></a>
        <a href="#"><i class="fa fa-linkedin"></i></a>
        <a href="#"><i class="fa fa-pinterest-p"></i></a>
      </div>
      <div class="humberger__menu__contact">
        <ul>
          <li><i class="fa fa-envelope"></i> hello@colorlib.com</li>
          <li>Frete Grátis para todas as Compra acima de R$50</li>
        </ul>
      </div>
    </div>
    <!-- Humberger End -->

    <!-- Header Section Begin -->
    <header class="header">
      <div class="header__top">
        <div class="container">
          <div class="row">
            <div class="col-lg-6 col-md-6">
              <div class="header__top__left">
                <ul>
                  <li><i class="fa fa-envelope"></i> hello@colorlib.com</li>
                  <li>Frete Grátis para todas as Compra acima de R$50</li>
                </ul>
              </div>
            </div>
            <div class="col-lg-6 col-md-6">
              <div class="header__top__right">
                <div class="header__top__right__social">
                  <a href="#"><i class="fa fa-facebook"></i></a>
                  <a href="#"><i class="fa fa-twitter"></i></a>
                  <a href="#"><i class="fa fa-linkedin"></i></a>
                  <a href="#"><i class="fa fa-pinterest-p"></i></a>
                </div>
                <div class="header__top__right__auth">
                  <a href="login.php"><i class="fa fa-user"></i> Login</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="container">
        <div class="row">
          <div class="col-lg-3">
            <div class="header__logo">
              <a href="./index.php"><img src="img/logo.png" alt="" /></a>
            </div>
          </div>
          <div class="col-lg-6">
            <nav class="header__menu">
              <ul>
                <li class="active"><a href="./index.php">Home</a></li>
                <li><a href="./shop-grid.html">Loja</a></li>
                <li>
                  <a href="#">Páginas</a>
                  <ul class="header__menu__dropdown">
                    <li>
                      <a href="./shop-details.html">Detalhes da Compra</a>
                    </li>
                    <li><a href="./shoping-cart.html">Carrinho</a></li>
                    <li><a href="./checkout.html">Check Out</a></li>
                    <li><a href="./blog-details.html">Detalhes Blog</a></li>
                  </ul>
                </li>
                <li><a href="./blog.html">Blog</a></li>
                <li><a href="./contact.html">Contato</a></li>
              </ul>
            </nav>
          </div>
          <div class="col-lg-3">
            <div class="header__cart">
              <ul>
                <li>
                  <a href="#"><i class="fa fa-heart"></i> <span>1</span></a>
                </li>
                <li>
                  <a href="#"
                    ><i class="fa fa-shopping-bag"></i> <span>3</span></a
                  >
                </li>
              </ul>
              <div class="header__cart__price">
                itens: <span>R$150.00</span>
              </div>
            </div>
          </div>
        </div>
        <div class="humberger__open">
          <i class="fa fa-bars"></i>
        </div>
      </div>
    </header>
    <!-- Header Section End -->

    <!-- Hero Section Begin -->
    <section class="hero">
      <div class="container">
        <div class="row">
          <div class="col-lg-3">
            <div class="hero__categories">
              <div class="hero__categories__all">
                <i class="fa fa-bars"></i>
                <span>Todos os Conteúdos</span>
              </div>
              <ul>
                <li><a href="#">Marvel</a></li>
                <li><a href="#">DC Comics</a></li>
                <li><a href="#">Quadrinhos</a></li>
                <li><a href="#">Mangás</a></li>
              </ul>
            </div>
          </div>
          <div class="col-lg-9">
            <div class="hero__search">
              <div class="hero__search__form">
                <form action="#">
                  <div class="hero__search__categories">
                    Todos os Conteúdos
                    <span class="arrow_carrot-down"></span>
                  </div>
                  <input type="text" placeholder="O que você procura?" />
                  <button type="submit" class="site-btn">PESQUISAR</button>
                </form>
              </div>
              <div class="hero__search__phone">
                <div class="hero__search__phone__icon">
                  <i class="fa fa-phone"></i>
                </div>
                <div class="hero__search__phone__text">
                  <h5>+65 11.188.888</h5>
                  <span>suporte 24H</span>
                </div>
              </div>
            </div>
            <div class="hero__item set-bg" data-setbg="img/hero/banner.jpg">
              <div class="hero__text">
                <span>OFERTA</span>
                <h2>PAGUE UM <br />LEVE DOIS</h2>
                <p>Apenas em itens selecionados</p>
                <a href="#" class="primary-btn">APROVEITE AGORA</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- Hero Section End -->

    <!-- Categories Section Begin -->
    <section class="categories">
      <div class="container">
        <div class="row">
          <div class="categories__slider owl-carousel">
            <div class="col-lg-3">
              <div
                class="categories__item set-bg"
                data-setbg="img/categories/marvel.png"
              >
                <h5><a href="#">Marvel</a></h5>
              </div>
            </div>
            <div class="col-lg-3">
              <div
                class="categories__item set-bg"
                data-setbg="img/categories/dc.png"
              >
                <h5><a href="#">DC Comics</a></h5>
              </div>
            </div>
            <div class="col-lg-3">
              <div
                class="categories__item set-bg"
                data-setbg="img/categories/monica.png"
              >
                <h5><a href="#">Mônica</a></h5>
              </div>
            </div>
            <div class="col-lg-3">
              <div
                class="categories__item set-bg"
                data-setbg="img/categories/manga.jpg">
                <h5><a href="#">Mangás</a></h5>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- Categories Section End -->

    <!-- Featured Section Begin -->
    <section class="featured spad">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="section-title">
              <h2>Todos os Produtos</h2>
            </div>
            <div class="featured__controls">
              <ul>
                <li class="active" data-filter="*">Todos</li>
                <li data-filter=".marvel">Marvel</li>
                <li data-filter=".dc-comics">DC Comics</li>
                <li data-filter=".quadrinhos">Mônica</li>
                <li data-filter=".mangas">Mangás</li>
              </ul>
            </div>
          </div>
        </div>
        <div class="row featured__filter">
          <div class="col-lg-3 col-md-4 col-sm-6 mix dc-comics">
            <div class="featured__item">
              <div
                class="featured__item__pic set-bg"
                data-setbg="img/featured/feature-1.jpg"
              >
                <ul class="featured__item__pic__hover">
                  <li>
                    <a href="#"><i class="fa fa-heart"></i></a>
                  </li>
                  <li>
                    <a href="#"><i class="fa fa-retweet"></i></a>
                  </li>
                  <li>
                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                  </li>
                </ul>
              </div>
              <div class="featured__item__text">
                <h6><a href="#">A Saga do Batman Vol. 63</a></h6>
                <h5>R$39,90</h5>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-4 col-sm-6 mix dc-comics">
            <div class="featured__item">
              <div
                class="featured__item__pic set-bg"
                data-setbg="img/featured/feature-2.jpg"
              >
                <ul class="featured__item__pic__hover">
                  <li>
                    <a href="#"><i class="fa fa-heart"></i></a>
                  </li>
                  <li>
                    <a href="#"><i class="fa fa-retweet"></i></a>
                  </li>
                  <li>
                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                  </li>
                </ul>
              </div>
              <div class="featured__item__text">
                <h6><a href="#">Hera Venenosa Vol. 01</a></h6>
                <h5>R$32,50</h5>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-4 col-sm-6 mix dc-comics">
            <div class="featured__item">
              <div
                class="featured__item__pic set-bg"
                data-setbg="img/featured/feature-3.jpg"
              >
                <ul class="featured__item__pic__hover">
                  <li>
                    <a href="#"><i class="fa fa-heart"></i></a>
                  </li>
                  <li>
                    <a href="#"><i class="fa fa-retweet"></i></a>
                  </li>
                  <li>
                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                  </li>
                </ul>
              </div>
              <div class="featured__item__text">
                <h6><a href="#">Liga da Justiça Vol. 61</a></h6>
                <h5>R$22,90</h5>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-4 col-sm-6 mix marvel">
            <div class="featured__item">
              <div
                class="featured__item__pic set-bg"
                data-setbg="img/featured/feature-4.jpg"
              >
                <ul class="featured__item__pic__hover">
                  <li>
                    <a href="#"><i class="fa fa-heart"></i></a>
                  </li>
                  <li>
                    <a href="#"><i class="fa fa-retweet"></i></a>
                  </li>
                  <li>
                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                  </li>
                </ul>
              </div>
              <div class="featured__item__text">
                <h6><a href="#">Deadpool Capa Variante Vol. 2</a></h6>
                <h5>$59,90</h5>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-4 col-sm-6 mix marvel">
            <div class="featured__item">
              <div
                class="featured__item__pic set-bg"
                data-setbg="img/featured/feature-5.jpg"
              >
                <ul class="featured__item__pic__hover">
                  <li>
                    <a href="#"><i class="fa fa-heart"></i></a>
                  </li>
                  <li>
                    <a href="#"><i class="fa fa-retweet"></i></a>
                  </li>
                  <li>
                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                  </li>
                </ul>
              </div>
              <div class="featured__item__text">
                <h6><a href="#">Spider-Punk Vol. 1</a></h6>
                <h5>R$45,90</h5>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-4 col-sm-6 mix marvel">
            <div class="featured__item">
              <div
                class="featured__item__pic set-bg"
                data-setbg="img/featured/feature-6.jpg"
              >
                <ul class="featured__item__pic__hover">
                  <li>
                    <a href="#"><i class="fa fa-heart"></i></a>
                  </li>
                  <li>
                    <a href="#"><i class="fa fa-retweet"></i></a>
                  </li>
                  <li>
                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                  </li>
                </ul>
              </div>
              <div class="featured__item__text">
                <h6><a href="#">Amazing Spider-Man #23 Disney What If Infinity Gauntlet</a></h6>
                <h5>R$30,00</h5>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-4 col-sm-6 mix mangas">
            <div class="featured__item">
              <div
                class="featured__item__pic set-bg"
                data-setbg="img/featured/feature-7.jpg"
              >
                <ul class="featured__item__pic__hover">
                  <li>
                    <a href="#"><i class="fa fa-heart"></i></a>
                  </li>
                  <li>
                    <a href="#"><i class="fa fa-retweet"></i></a>
                  </li>
                  <li>
                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                  </li>
                </ul>
              </div>
              <div class="featured__item__text">
                <h6><a href="#">Blue Period Vol. 1</a></h6>
                <h5>R$34,90</h5>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-4 col-sm-6 mix mangas">
            <div class="featured__item">
              <div
                class="featured__item__pic set-bg"
                data-setbg="img/featured/feature-8.jpg"
              >
                <ul class="featured__item__pic__hover">
                  <li>
                    <a href="#"><i class="fa fa-heart"></i></a>
                  </li>
                  <li>
                    <a href="#"><i class="fa fa-retweet"></i></a>
                  </li>
                  <li>
                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                  </li>
                </ul>
              </div>
              <div class="featured__item__text">
                <h6><a href="#">Kuroko no Basket Vol. 6</a></h6>
                <h5>R$24,90</h5>
              </div>
            </div>
          </div>
          
          <div class="col-lg-3 col-md-4 col-sm-6 mix quadrinhos">
            <div class="featured__item">
              <div
                class="featured__item__pic set-bg"
                data-setbg="img/featured/feature-9.jpg"
              >
                <ul class="featured__item__pic__hover">
                  <li>
                    <a href="#"><i class="fa fa-heart"></i></a>
                  </li>
                  <li>
                    <a href="#"><i class="fa fa-retweet"></i></a>
                  </li>
                  <li>
                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                  </li>
                </ul>
              </div>
              <div class="featured__item__text">
                <h6><a href="#">Mônica(2021) Vol. 26</a></h6>
                <h5>R$8,00</h5>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-4 col-sm-6 mix quadrinhos">
            <div class="featured__item">
              <div
                class="featured__item__pic set-bg"
                data-setbg="img/featured/feature-10.jpg"
              >
                <ul class="featured__item__pic__hover">
                  <li>
                    <a href="#"><i class="fa fa-heart"></i></a>
                  </li>
                  <li>
                    <a href="#"><i class="fa fa-retweet"></i></a>
                  </li>
                  <li>
                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                  </li>
                </ul>
              </div>
              <div class="featured__item__text">
                <h6><a href="#">Magali(2021) Vol.34</a></h6>
                <h5>R$8,00</h5>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-4 col-sm-6 mix quadrinhos">
            <div class="featured__item">
              <div
                class="featured__item__pic set-bg"
                data-setbg="img/featured/feature-11.jpg"
              >
                <ul class="featured__item__pic__hover">
                  <li>
                    <a href="#"><i class="fa fa-heart"></i></a>
                  </li>
                  <li>
                    <a href="#"><i class="fa fa-retweet"></i></a>
                  </li>
                  <li>
                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                  </li>
                </ul>
              </div>
              <div class="featured__item__text">
                <h6><a href="#">Cebolinha(2021) Vol. 39</a></h6>
                <h5>R$8,00</h5>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-4 col-sm-6 mix quadrinhos">
            <div class="featured__item">
              <div
                class="featured__item__pic set-bg"
                data-setbg="img/featured/feature-12.jpg"
              >
                <ul class="featured__item__pic__hover">
                  <li>
                    <a href="#"><i class="fa fa-heart"></i></a>
                  </li>
                  <li>
                    <a href="#"><i class="fa fa-retweet"></i></a>
                  </li>
                  <li>
                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                  </li>
                </ul>
              </div>
              <div class="featured__item__text">
                <h6><a href="#">Cascão(2021) Vol. 29</a></h6>
                <h5>R$8,00</h5>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- Featured Section End -->

    <!-- Banner Begin -->
    <div class="banner">
      <div class="container">
        <div class="row">
          <div class="col-lg-6 col-md-6 col-sm-6">
            <div class="banner__pic">
              <img src="img/banner/banner-1.jpg" alt="" />
            </div>
          </div>
          <div class="col-lg-6 col-md-6 col-sm-6">
            <div class="banner__pic">
              <img src="img/banner/banner-2.jpg" alt="" />
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Banner End -->

    <!-- Latest Product Section Begin -->
    <section class="latest-product spad">
      <div class="container">
        <div class="row">
          <div class="col-lg-4 col-md-6">
            <div class="latest-product__text">
              <h4>Novidades</h4>
              <div class="latest-product__slider owl-carousel">
                <div class="latest-prdouct__slider__item">
                  <a href="#" class="latest-product__item">
                    <div class="latest-product__item__pic">
                      <img src="img/latest-product/lp-1.jpg" alt="" />
                    </div>
                    <div class="latest-product__item__text">
                      <h6>The Sandman Vol. 1: Preludes & Nocturnes 30th Anniversary Edition</h6>
                      <span>R$100,00</span>
                    </div>
                  </a>
                  <a href="#" class="latest-product__item">
                    <div class="latest-product__item__pic">
                      <img src="img/latest-product/lp-2.jpg" alt="" />
                    </div>
                    <div class="latest-product__item__text">
                      <h6>Marvel Action: Spider-man Vol.1</h6>
                      <span>R$26,90</span>
                    </div>
                  </a>
                  <a href="#" class="latest-product__item">
                    <div class="latest-product__item__pic">
                      <img src="img/latest-product/lp-3.jpg" alt="" />
                    </div>
                    <div class="latest-product__item__text">
                      <h6>Turma da Mônica Jovem 50: O Casamento do Século</h6>
                      <span>R$10,00</span>
                    </div>
                  </a>
                </div>
                <div class="latest-prdouct__slider__item">
                  <a href="#" class="latest-product__item">
                    <div class="latest-product__item__pic">
                      <img src="img/latest-product/lp-1.jpg" alt="" />
                    </div>
                    <div class="latest-product__item__text">
                      <h6>The Sandman Vol. 1: Preludes & Nocturnes 30th Anniversary Edition</h6>
                      <span>R$100,00</span>
                    </div>
                  </a>
                  <a href="#" class="latest-product__item">
                    <div class="latest-product__item__pic">
                      <img src="img/latest-product/lp-2.jpg" alt="" />
                    </div>
                    <div class="latest-product__item__text">
                      <h6>Marvel Action: Spider-man Vol.1</h6>
                      <span>R$26,90</span>
                    </div>
                  </a>
                  <a href="#" class="latest-product__item">
                    <div class="latest-product__item__pic">
                      <img src="img/latest-product/lp-3.jpg" alt="" />
                    </div>
                    <div class="latest-product__item__text">
                      <h6>Turma da Mônica Jovem 50: O Casamento do Século</h6>
                      <span>R$10,00</span>
                    </div>
                  </a>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-6">
            <div class="latest-product__text">
              <h4>Mais Amados</h4>
              <div class="latest-product__slider owl-carousel">
                <div class="latest-prdouct__slider__item">
                  <a href="#" class="latest-product__item">
                    <div class="latest-product__item__pic">
                      <img src="img/featured/feature-2.jpg" alt="" />
                    </div>
                    <div class="latest-product__item__text">
                      <h6>Hera Venenosa Vol. 01</h6>
                      <span>R$32,50</span>
                    </div>
                  </a>
                  <a href="#" class="latest-product__item">
                    <div class="latest-product__item__pic">
                      <img src="img/featured/feature-7.jpg" alt="" />
                    </div>
                    <div class="latest-product__item__text">
                      <h6>Blue Period Vol.1</h6>
                      <span>R$34,90</span>
                    </div>
                  </a>
                  <a href="#" class="latest-product__item">
                    <div class="latest-product__item__pic">
                      <img src="img/featured/feature-11.jpg" alt="" />
                    </div>
                    <div class="latest-product__item__text">
                      <h6>Cebolinha(2021) Vol. 39</h6>
                      <span>R$8,00</span>
                    </div>
                  </a>
                </div>
                <div class="latest-prdouct__slider__item">
                  <a href="#" class="latest-product__item">
                    <div class="latest-product__item__pic">
                      <img src="img/featured/feature-2.jpg" alt="" />
                    </div>
                    <div class="latest-product__item__text">
                      <h6>Hera Venenosa Vol. 01</h6>
                      <span>R$32,50</span>
                    </div>
                  </a>
                  <a href="#" class="latest-product__item">
                    <div class="latest-product__item__pic">
                      <img src="img/featured/feature-7.jpg" alt="" />
                    </div>
                    <div class="latest-product__item__text">
                      <h6>Blue Period Vol.1</h6>
                      <span>R$34,90</span>
                    </div>
                  </a>
                  <a href="#" class="latest-product__item">
                    <div class="latest-product__item__pic">
                      <img src="img/featured/feature-11.jpg" alt="" />
                    </div>
                    <div class="latest-product__item__text">
                      <h6>Cebolinha(2021) Vol. 39</h6>
                      <span>R$8,00</span>
                    </div>
                  </a>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-6">
            <div class="latest-product__text">
              <h4>Mais Avaliados</h4>
              <div class="latest-product__slider owl-carousel">
                <div class="latest-prdouct__slider__item">
                  <a href="#" class="latest-product__item">
                    <div class="latest-product__item__pic">
                      <img src="img/product/product-10.jpg" alt="" />
                    </div>
                    <div class="latest-product__item__text">
                      <h6>Violet Evergarden Vol. 2</h6>
                      <span>R$50,00</span>
                    </div>
                  </a>
                  <a href="#" class="latest-product__item">
                    <div class="latest-product__item__pic">
                      <img src="img/product/product-4.jpg" alt="" />
                    </div>
                    <div class="latest-product__item__text">
                      <h6>Batman/Superman: Os Melhores do Mundo Vol. 3</h6>
                      <span>R$19,90</span>
                    </div>
                  </a>
                  <a href="#" class="latest-product__item">
                    <div class="latest-product__item__pic">
                      <img src="img/product/product-13.jpg" alt="" />
                    </div>
                    <div class="latest-product__item__text">
                      <h6>Demon Slayer - Kimetsu No Yaiba Vol. 1</h6>
                      <span>R$29,90</span>
                    </div>
                  </a>
                </div>
                <div class="latest-prdouct__slider__item">
                  <a href="#" class="latest-product__item">
                    <div class="latest-product__item__pic">
                      <img src="img/product/product-10.jpg" alt="" />
                    </div>
                    <div class="latest-product__item__text">
                      <h6>Violet Evergarden Vol. 2</h6>
                      <span>R$50,00</span>
                    </div>  
                  </a>
                  <a href="#" class="latest-product__item">
                    <div class="latest-product__item__pic">
                      <img src="img/product/product-4.jpg" alt="" />
                    </div>
                    <div class="latest-product__item__text">
                      <h6>Batman/Superman: Os Melhores do Mundo Vol. 3</h6>
                      <span>R$19,90</span>
                    </div>
                  </a>
                  <a href="#" class="latest-product__item">
                    <div class="latest-product__item__pic">
                      <img src="img/product/product-13.jpg" alt="" />
                    </div>
                    <div class="latest-product__item__text">
                      <h6>Demon Slayer - Kimetsu No Yaiba Vol. 1</h6>
                      <span>R$29,90</span>
                    </div>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- Latest Product Section End -->

    <!-- Blog Section Begin -->
    <section class="from-blog spad">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="section-title from-blog__title">
              <h2>Do nosso Blog</h2>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-4 col-md-4 col-sm-6">
            <div class="blog__item">
              <div class="blog__item__pic">
                <img src="img/blog/blog-1.jpg" alt="" />
              </div>
              <div class="blog__item__text">
                <ul>
                  <li><i class="fa fa-calendar-o"></i> Set 17,2023</li>
                  <li><i class="fa fa-comment-o"></i> 10</li>
                </ul>
                <h5><a href="#">O Universo Marvel: Heróis, Vilões e Histórias Épicas</a></h5>
                <p>
                  Explore o rico multiverso da Marvel, repleto de superpoderes, dramas e batalhas épicas que cativaram gerações.
                </p>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-4 col-sm-6">
            <div class="blog__item">
              <div class="blog__item__pic">
                <img src="img/blog/blog-2.jpg" alt="" />
              </div>
              <div class="blog__item__text">
                <ul>
                  <li><i class="fa fa-calendar-o"></i> Dez 21, 2022</li>
                  <li><i class="fa fa-comment-o"></i> 7</li>
                </ul>
                <h5><a href="#">DC Comics: O Lar dos Maiores Super-Heróis do Mundo</a></h5>
                <p>
                  Conheça os icônicos personagens da DC, como Batman, Superman e Mulher-Maravilha, e mergulhe em suas lendárias aventuras.
                </p>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-4 col-sm-6">
            <div class="blog__item">
              <div class="blog__item__pic">
                <img src="img/blog/blog-3.jpg" alt="" />
              </div>
              <div class="blog__item__text">
                <ul>
                  <li><i class="fa fa-calendar-o"></i> Jan 6,2023</li>
                  <li><i class="fa fa-comment-o"></i> 35</li>
                </ul>
                <h5><a href="#">Turma da Mônica: A Magia dos Quadrinhos Brasileiros</a></h5>
                <p>
                  Descubra como as adoráveis histórias da Turma da Mônica encantam leitores de todas as idades no Brasil e além.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- Blog Section End -->

    <!-- Footer Section Begin -->
    <footer class="footer spad">
      <div class="container">
        <div class="row">
          <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="footer__about">
              <div class="footer__about__logo">
                <a href="./index.php"><img src="img/logo.png" alt="" /></a>
              </div>
              <ul>
                <li>Endereço: 60-49 Road 11378 New York</li>
                <li>Telefone: +65 11.188.888</li>
                <li>Email: hello@colorlib.com</li>
              </ul>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 col-sm-6 offset-lg-1">
            <div class="footer__widget">
              <h6>Links Úteis</h6>
              <ul>
                <li><a href="#">Sobre Nós</a></li>
                <li><a href="#">Sobre nossa Loja</a></li>
                <li><a href="#">Segurança na Compra</a></li>
                <li><a href="#">Delivery infomation</a></li>
                <li><a href="#">Política de Privacidade</a></li>
                <li><a href="#">Nosso Sitemap</a></li>
              </ul>
              <ul>
                <li><a href="#">Quem nós somos</a></li>
                <li><a href="#">Nossos </a></li>
                <li><a href="#">Projetos</a></li>
                <li><a href="#">Contato</a></li>
                <li><a href="#">Inivação</a></li>
                <li><a href="#">Feedbacks</a></li>
              </ul>
            </div>
          </div>
          <div class="col-lg-4 col-md-12">
            <div class="footer__widget">
              <h6>Inscreva-se na nossa Newsletter Agora</h6>
              <p>Receba e-mails sobre nossas novidade e ofertas especiais.</p>
              <form action="#">
                <input type="text" placeholder="Insira seu e-mail" />
                <button type="submit" class="site-btn">Inscreva-se</button>
              </form>
              <div class="footer__widget__social">
                <a href="#"><i class="fa fa-facebook"></i></a>
                <a href="#"><i class="fa fa-instagram"></i></a>
                <a href="#"><i class="fa fa-twitter"></i></a>
                <a href="#"><i class="fa fa-pinterest"></i></a>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-12">
            <div class="footer__copyright">
              <div class="footer__copyright__text">
                <p>
                  <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                  Copyright &copy;
                  <script>
                    document.write(new Date().getFullYear());
                  </script>
                  Todos os direitos reservados | Esse template foi feito por
                  <i class="fa fa-heart" aria-hidden="true"></i> by
                  <a href="https://colorlib.com" target="_blank">Colorlib</a>
                  <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                </p>
              </div>
              <div class="footer__copyright__payment">
                <img src="img/payment-item.png" alt="" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
    <!-- Footer Section End -->

    <!-- Js Plugins -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/mixitup.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>
  </body>
</html>
