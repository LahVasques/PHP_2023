<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "loja";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar a conexão
if (!$conn) {
    die("Falha na conexão: " . mysqli_connect_error());
}

// Dados do usuário a serem verificados (supondo que você tenha um formulário para isso)
$emailParaVerificar = $_POST['email'];
$senhaParaVerificar = $_POST['senha'];

// Consulta SQL para verificar o login
$sql = "SELECT * FROM usuarios WHERE email = '$emailParaVerificar' AND senha = '$senhaParaVerificar'";
$resultado = mysqli_query($conn, $sql);

// Verificar se a consulta foi bem-sucedida e se há um registro correspondente
if (mysqli_num_rows($resultado) == 1) {
    header("Location: index.php");
} else {
    header("Location: login.php");
}

// Fechar a conexão com o banco de dados
mysqli_close($conn);



// require_once "conexao2.php";
// // Obter os dados do formulário
// // $nome = $_POST["nome"];
// $email = $_POST["email"];
// $senha = $_POST["senha"];
// // Inserir os dados na tabela 'usuario'
// $sql = "SELECT * FROM usuarios (email, senha) VALUES 
// ('$email', '$senha')";

// if ($conn->query($sql) === TRUE) {
//     header("Location: index.php");
//     exit();    
// } else {
//     echo "Erro ao cadastrar o usuario: " . $conn->error;
// }
// $conn->close();
?>